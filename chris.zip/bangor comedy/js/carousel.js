$(document).ready(function(){
      $('.carousel').slick({
        autoplay: true
      });
        
      
    });